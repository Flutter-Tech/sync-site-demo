# git flutter CLI

This repository contains the `git flutter` CLI.

- Usage [is documented on the inner source site](https://innersource.flutter.com/git-flutter/).
- Support is provided by the Inner Source Team (Slack on [#inner-source slack channel](https://slack.com/app_redirect?channel=C0115SW13V5), or email `InnerSourceTeam@flutter.com`)

Direct usage of this repository is for CLI contributors:

- Local install, test, lint and software architecture [are described in the CONTRIBUTING.md document](CONTRIBUTING.md).
- Integration tests are [described in integration/README.md document](integration/README.md).
- Command conventions are [described in cmd/README.md document](cmd/README.md).
